<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body class="bg-dark">
  <div class="container">

    <div class="card card-login mx-auto mt-5">
      <img src="<?php echo base_url('assets/logo/logo2.png'); ?>">
      <div class="card-header img-fluid"  alt="Responsive image" style="text-align: center;"></div>
      <div class="card-body">       
        <div class="alert alert-info">
          <strong>Info!</strong> Thank you for your time on confirming your password changed.<br />
           You can now login <a style="text-decoration: underline;" href="<?php echo base_url(); ?>">Login Now</a>
        </div>
      </div>
    </div>
  </div>
</body>