  <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title> WE TALK INC</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap-datepicker3.min.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap-glyphicons.css'); ?>" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url('assets/vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
  
  <link  href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/googlefont.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/googletekofont.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/sb-admin.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/custom.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/select.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('flag-icon-css-master/css/flag-icon.css'); ?>" rel="stylesheet">
  
  <link  href="<?php echo base_url('assets/css/print/jquery.dataTables.min.css'); ?>" rel="stylesheet">
  <link  href="<?php echo base_url('assets/css/print/buttons.dataTables.min.css'); ?>" rel="stylesheet">
 
</head>
